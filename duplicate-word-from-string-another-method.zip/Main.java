
public class Main
{
	public static void main(String[] args) {
		String s ="hello hi hi jo";
		String[]a=new String[s.length()];
		a=s.split(" ");
		for(int i=0;i<a.length;i++){
		    int flag =0;
		    for(int j=0;j<i;j++)
		    {
		        if(a[i].equals(a[j])){
		            flag=1;
		            break;
		        }
		        
		    } if(flag==0){
		        System.out.print(a[i]+" ");
		    }
		    
		}
	}
}
